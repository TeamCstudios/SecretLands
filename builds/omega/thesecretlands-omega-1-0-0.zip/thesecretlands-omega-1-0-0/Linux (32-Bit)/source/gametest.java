import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class gametest extends PApplet {

int xpos = 1000;
int ypos = 1000;
int xm = 0;
int ym = 0;
int lastxpos = 9999;
int lastypos = 9999;
int scene = 0;
int tileValue;
int inputCodea;
int inputCodeb;
boolean sprint;
public void setup(){
  frameRate(120);
   
  background(100);
  textSize(36);
}

public void draw(){
  if(scene == 0){
    background(100);
    fill(255);
    textSize(50);
    text("The Secret Lands",300,50);
    textSize(36);
    text("World Generation: <-" + preset + "->",20,300);
    text("Press SHIFT to continue",20,680);
    textSize(10);
    text("0: Normal",20,320);
    text("1: Southwestern Europe",20,330);
    text("2: Hyrule",20,340);
    text("3: Middle East",20,350);
    text("4: Indonesia",20,360);
    text("5: Desert Archipelago",20,370);
    text("6: Winter Wonderland",20,380);
    text("7: China",20,390);
    text("8: Random",20,400);
    text("The Secret Lands belongs to Team CStudios Organization.",700,200);
    text("All programming created by MrJoCrafter (2020-)",700,210);
    text("Terrain algorithm by Yoctobyte and MrJoCrafter (2017-2019)",700,220);
  }else if(scene == 1){
    background(100);
    fill(255);
    text("Generating World... This may take a moment.",150,300);
    scene = 2;
  }else if(scene == 2){
    background(100);
    terrainGenSetup();
    terrainGenDraw();
    drawTerrain();
    while(tileValue <= 6 || tileValue >= 16){
      xpos = PApplet.parseInt(random(200) + 200);
      ypos = PApplet.parseInt(random(200) + 200);
      drawTerrain();
    }
    scene = 3;
  }else if(scene == 3){
    background(0,0,240); 
    drawTerrain();
    collision();
  }
  textSize(10);
  fill(45);
  text("The Secret Lands, Version 1.0.0 Omega",800,690);
  if(scene == 3){
    text("{" + xpos + "," + ypos + "}",10,690);
  }  
  textSize(36);
}

public void keyPressed(){
  if(scene == 3){
    if(keyCode == UP){
      ym -= 2;
    } 
    if(keyCode == DOWN){
      ym += 2;
    } 
    if(keyCode == RIGHT){
      xm += 2;
    } 
    if(keyCode == LEFT){
      xm -= 2;
    }  
  }else if(scene == 0){
    if(keyCode == RIGHT){
      if(preset < 8){
        preset++;
      }
    } 
    if(keyCode == LEFT){
      if(preset > 0){
        preset--;
      }
    }
    if(keyCode == SHIFT){
    scene = 1;
    }
  }
}
public void collision(){
  lastxpos = xpos;
  lastypos = ypos;
  if(xm > 0 && ym > 0){
    xm--;
    ym--;
  }else if(xm < 0 && ym > 0){
    xm++;
    ym--;
  }else if(xm > 0 && ym < 0){
    xm--;
    ym++;
  }else if(xm < 0 && ym < 0){
    xm++;
    ym++;
  }else
  if(xm > 0){
    xpos++;
    xm--;
  }else if(xm < 0){
    xpos--;
    xm++;
  }
  if(ym > 0){
    ypos++;
    ym--;
  }else if(ym < 0){
    ypos--;
    ym++;
  }
  
  drawTerrain();
  if(tileValue <= 6 || tileValue >= 16){
    xpos = lastxpos;
    ypos = lastypos;
    drawTerrain();
  }
  if(sprint){
    sprint = false;
  }
}
/*
Mountains:
1: Volcano (250,10,10)
2-4: Mountain Peak (60) (70) (80)
5-6: Mountain (95) (110)
7: Foothills (155)

Plains:
8: Grasslands (0,255,0)
9: Dark Grasslands (0,245,0)

Desert:
10: Desert (255,255,80)
11: Desert Transition (240,240,100)
11: Beach (240,240,100)

Tundra:
12: Tundra (255)
13: Tundra Transition (225,235,245)

Forest:
14: Forest (0,180,0)
15: Forest Transition (0,220,0)

Ocean:
16: Ocean (0,0,255)
17: Deep Ocean (0,0,240)
*/

int[][] map = new int[2001][2001];

public void drawTerrain(){
  int value;
  for(int i = 0; i < (width / 10); i++){for(int j = 0; j < (height / 10); j++){
    
    value = map[abs((xpos+i) % 2000)][abs((ypos+j) % 2001)];
    if(value == 1){fill(250,10,10);}
    else if(value == 2){fill(60);}
    else if(value == 3){fill(70);}
    else if(value == 4){fill(80);}
    else if(value == 5){fill(95);}
    else if(value == 6){fill(110);}
    else if(value == 7){fill(155);}
    else if(value == 8){fill(0,255,0);}
    else if(value == 9){fill(0,245,0);}
    else if(value == 10){fill(255,255,80);}
    else if(value == 11){fill(240,240,100);}
    else if(value == 12){fill(255);}
    else if(value == 13){fill(225,235,245);}
    else if(value == 14){fill(0,180 - 20 * (i % 2) - 20 * (j % 2),0);}
    else if(value == 15){fill(0,220 - 20 * (j % 2) - 20 * (i % 2),0);}
    else if(value == 16){fill(0,0,255);}
    else if(value == 17){fill(0,0,240);}
    rectMode(CORNER);
    if(i == (width/20) && j == (height/20)){
      tileValue = value;
      fill(255,0,0);
    }
    rect(i * 10,j * 10,10,10);
    
  }}
}
/*
            Terrain Generator
    Created by Yoctobyte and MrJoCrafter

                  Presets
0: Normal
1: Southwestern Europe
2: Hyrule
3: Middle East
4: Indonesia
5: Desert Archipelago
6: Winter Wonderland
7: China
8: Random
*/
int preset = 0;
float s = 1;
float l = 0.5f;
float bc = 0.04f;
float speed = 4000000;
float x = 0;
float y = -s;
float t0 = 1;
float t1 = 1;
float r0 = 1;
float c0 = 0.01f;
float c1 = 0.01f;
float br0 = 1;
float bt0 = 2;
float bt1 = 2;
float bc0 = 0.01f;
float bc1 = 0.01f;
float bl = 0.6f;
float bb = 0.01f;
float wr0 = 1;
float wt0 = 5;
float wt1 = 5;
float wc0 = 0.01f;
float wc1 = 0.01f;
float wl = 0.50f;
float wb = 0.05f;
float tr0 = 1;
float tt0 = 10;
float tt1 = 10;
float tc0 = 0.01f;
float tc1 = 0.01f;
float tl = 0.5f;
float fc = 1;
float rbnd = 0;

//Set the window size and certain other parameters
public void terrainGenSetup(){
  noStroke(); 
  if (preset == 1){l = 0.299f;tl = 0.6f;} 
  else if (preset == 2){l = 0.189f;tl = 0.6f;} 
  else if (preset == 3){l = 0.45f;tl = 0.9f;wl = 0.2f;bc = 0.1f;bl = 0.8f;} 
  else if (preset == 4){l = 0.6f;tl = 0.8f;wl = 0.7f;bl = 0.3f;} 
  else if (preset == 5){l = 0.8f;tl = 0.9f;wl = 0.2f;bl = 0.9f;bc = 0.1f;} 
  else if (preset == 6){wl = 0.2f;tl = 0.1f;l = .4f;bl = 0.7f;} 
  else if (preset == 7){l = .4f;wl = 0.8f;tl = 0.5f;bl = 0.55f;} 
  else if (preset == 8){l = random(1);wl = random(1);tl = random(1);bl = random(1);bc = random(1);} 
  else if (preset == 11){c0 = .1f;}
}

//Generate the terrain
public void terrainGenDraw() { int z = 0; for(int i = 0; i < speed; i ++) {
  r0 = noise(t0,t1); 
  br0 = noise(bt0,bt1);
  wr0 = noise(wt0,wt1); 
  tr0 = noise(tt0,tt1);
  if(r0 > l*2.1f && wr0 > wl && br0 > bl){
    // Volcano
    z = 1;
  }else if(r0 > l*2){
    // Mountain
    z = 2;
  }else if(r0 > l*1.9f){
    // Mountain
    z = 3;
  }else if(r0 > l*1.8f){
    // Mountain
    z = 4;
  }else if(r0 > l*1.7f){
    // Mountain
    z = 5;
  }else if(r0 > l*1.6f){
    // Mountain
    z = 6;
  }else if(r0 > l*1.5f){
    // Mountain
    z = 7;
  }else if(r0 > l ){ 
    // Plains Biome
    z = 8;
    if(tr0 < tl-.1f){
      if(wr0 > wl){ 
      // Desert Biome
      z = 10; 
      } 
      if(wr0 > wl-wb && wr0 < wl){ 
      // Desert Transition Biome
      z = 11; 
      } 
    }else if(tr0 > tl+.1f){
      if(wr0 > wl){ 
      // Winter Biome
      z = 12; 
      } else if(wr0 > wl-wb && wr0 < wl){ 
      // Winter Transition Biome
      z = 13; 
      }
    }else{
      // Darkgrass Biome
      z = 9;
    }
    if(br0 > bl){ 
    // Forest Biome
    z = 14;
    } 
    if(br0 > bl-bb && br0 < bl){ 
    // Forest Transition
    z = 15;
    } 
  }else if(r0 > (l-bc) && r0 < l){ 
    // Beach
    z = 11; 
  }else if(r0 < l*0.5f){
    // Deep Ocean
    z = 17;
  }else{
    // Ocean
    z = 16;
  }
  map[PApplet.parseInt(x)][PApplet.parseInt(y) + 1] = z; 
  x += s;
  if(x > 2000) { x = 0; y += s; t0 = 1;  t1 += c1; bt1 += bc1; bt0 = 1; wt1 += wc1; wt0 = 1; tt1 += tc1; tt0 = 1;}
  t0 += c0; bt0 += bc0; wt0 += wc0; tt0 += tc0;}}
  public void settings() {  size(1000,700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "gametest" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
