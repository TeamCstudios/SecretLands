import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class secretlands extends PApplet {

int xpos;int ypos;int xm = 0;int ym = 0;int lastxpos = 9999;int lastypos = 9999;int scene = 0;int tileValue;int tileSelectedValue;int selection;
int selDir = 1;int selX;int selY;int objectValue;int currentObjectID;int inputCodea;int inputCodeb;boolean sprint;int cSpeed = 1;int playerColor = 1;
int countdown = -1;int framecounter = 1;int frameruleCounter = 0;

public void settings(){
  size(1000,700); 
}
public void setup(){
  frameRate(60);
  background(100);
  textSize(36);
}

public void draw(){
  if(scene == 0){
    initialize();
    background(100);
    fill(255);
    textSize(50);
    text("The Secret Lands",300,50);
    textSize(36);
    text("World Generation: <-" + preset + "->",20,300);
    text("Press SHIFT to continue",20,680);
    textSize(10);
    text("0: Normal",20,320);
    text("1: Southwestern Europe",20,330);
    text("2: Mountain Barriers",20,340);
    text("3: Middle East",20,350);
    text("4: Indonesia",20,360);
    text("5: Desert Archipelago",20,370);
    text("6: Winter Wonderland",20,380);
    text("7: China",20,390);
    text("8: Random (unstable)",20,400);
    text("9: Europa",20,410);
    text("The Secret Lands belongs to Team CStudios Organization.",700,200);
    text("All programming created by MrJoCrafter (2020-)",700,210);
    text("Terrain algorithm by Yoctobyte and MrJoCrafter (2017-2019)",700,220);
    text("Controls",600,400);
    text("Arrow Keys / WASD: Move/Select",600,410);
    text("E: Mine",600,420);
    text("I: Open/Close Inventory",600,430);
    text("Z: Change placing direction",600,440);
    text("X: Change selected block",600,450);
    text("Shift: Place block",600,460);
    text("+: Screenshot",600,470);
  }else if(scene == 1){
    background(100);
    fill(255);
    text("Generating World... This may take a moment.",150,300);
    scene = 2;
  }else if(scene == 2){
    background(100);
    terrainGenSetup();
    terrainGenDraw();
    createObjects();
    drawTerrain();
    while(tileValue <= 7 || tileValue >= 16){
      xpos = PApplet.parseInt(random(200) + 200);
      ypos = PApplet.parseInt(random(200) + 200);
      drawTerrain();
    }
    scene = 3;
  }else if(scene == 3){
    background(0,0,240); 
    drawTerrain();
    for(int rt = 0; rt < cSpeed; rt++){
      collision();
    }
    drawObjects();
    countdown();
    framecounter();
  }else if(scene == 4){
    background(86); 
    inventory();
  }
  textSize(10);
  fill(45);
  text("The Secret Lands, Version 1.3.0 Omega",800,690);
  if(scene == 3){
    text("{" + (xpos + (width/xFOV/2)) + "," + (ypos + (height/xFOV/2)) + "}",10,690);
    if(selection == 0){  
      text("Placing: None",470,690);
    }else if(selection == 1){  
      text("Placing: Wood",470,690);
    }else if(selection == 2){  
      text("Placing: Stone",470,690);
    }
  }  
  textSize(36);
}

public void keyPressed(){
  if(scene == 3){
    if(keyCode == UP || key == 'w' || key == 'W'){
      ym -= cSpeed;
    } 
    if(keyCode == DOWN || key == 's' || key == 'S'){
      ym += cSpeed;
    } 
    if(keyCode == RIGHT || key == 'd' || key == 'D'){
      xm += cSpeed;
    } 
    if(keyCode == LEFT || key == 'a' || key == 'A'){
      xm -= cSpeed ;
    }  
    if(key == '[' || key == '{'){
      scene = 0;
      playerColor = 1;
    }
    if(key == 'i' || key == 'I'){
      scene = 4;
    }   
    if(key == 'x' || key == 'X'){
      if(selection == 0){
        if(inventory[1] > 19){
          selection++;
        }else if(inventory[2] > 19){
          selection = 2;
        }
      } else if(selection == 1){
        if(inventory[2] > 19){
          selection = 2;
        }else{
          selection = 0;
        }
      }else if(selection == 2){
        selection = 0;
      }
    }
    if(key == 'z' || key == 'Z'){
      if(selDir < 4){
        selDir++;
      }else if(selDir == 4){
        selDir = 1;
      }
    }
    if(key == '+' || key == '='){
      textSize(69);
      text("Taking Screenshot...",100,450);
      textSize(36);
      takeScreenshot();
    }
    if(keyCode == SHIFT){
      if(inventory[selection] > 19){
        if(tileSelectedValue < 2 || (tileSelectedValue >= 16 && tileSelectedValue < 18)){
          map[selX][selY] = selection * -1;
          inventory[selection] -= 20;
          if(inventory[selection] < 20){
            selection = 0;
          }
        }
      }
    }
    if(key == 'e' || key == 'E'){
      if(playerColor == 1 || playerColor == 4){
        if(tileValue == 15){
          inventory[1]++;
          map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 8;
        }
        if(tileValue == 14){
          inventory[1]++;
          if(random(1) > .3f){
            inventory[1]++; 
          }
          map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 9;
        }
      } else if (playerColor == 3){
        if(tileValue == 2){
          inventory[2]++;
          map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 3;
        }
        if(tileValue == 3){
          inventory[2]++;
          map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 4;
        }
        if(tileValue == 4){
          inventory[2]++;
          map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 5;
        }
        if(tileValue == 5){
          inventory[2]++;
          map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 6;
        }
        if(tileValue == 6){
          inventory[2]++;
          map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 7;
        }
      }
    }
  }else if(scene == 0){
    if(keyCode == RIGHT){
      if(preset < 9){
        preset++;
      }
    } 
    if(keyCode == LEFT){
      if(preset > 0){
        preset--;
      }
    }
    if(keyCode == SHIFT){
      scene = 1;
    }
  }else if(scene == 4){
    if(key == 'i' || key == 'I'){
      scene = 3;
    }
    if(key == '1' || key == '!'){
      if(inventory[20] > 0){
        inventory[20]--;
        countdown = -1;
        playerColor = 1;
      }
    }
    if(key == '2' || key == '@'){
      if(inventory[21] > 0){
        inventory[21]--;
        countdown = 2144;
        playerColor = 2;
      }
    }
    if(key == '3' || key == '#'){
      if(inventory[22] > 0){
        inventory[22]--;
        countdown = 1926;
        playerColor = 3;
      }
    }
    if(key == '4' || key == '$'){
      if(inventory[23] > 0){
        inventory[23]--;
        countdown = 215;
        playerColor = 4;
      }
    }
    if(key == '5' || key == '%'){
      if(inventory[24] > 0){
        inventory[24]--;
        countdown = 412;
        playerColor = 5;
      }
    }
  }
}
public void collision(){
  lastxpos = xpos;
  lastypos = ypos;
  if(xm > 0){
    xpos++;
    if(tileValue != 18 || (random(1) > .2f)){
       xm--;
    }
  }else if(xm < 0){
    xpos--;
    if(tileValue != 18 || (random(1) > .2f)){
       xm++;
    }
  }
  if(ym > 0){
    ypos++;
    if(tileValue != 18 || (random(1) > .2f)){
       ym--;
    }
  }else if(ym < 0){
    ypos--;
    if(tileValue != 18 || (random(1) > .2f)){
       ym++;
    }
  }
  if(playerColor == 5 && tileValue == 16){
    map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)] = 18;
    if(map[xpos + (width/xFOV/2) + 1][ypos + (height/xFOV/2)] == 16){
      map[xpos + (width/xFOV/2) + 1][ypos + (height/xFOV/2)] = 18;
    }
    if(map[xpos + (width/xFOV/2) + 1][ypos + (height/xFOV/2) + 1] == 16){
      map[xpos + (width/xFOV/2) + 1][ypos + (height/xFOV/2)+ 1] = 18;
    }
    if(map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2) + 1] == 16){
      map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)+ 1] = 18;
    }
    if(map[xpos + (width/xFOV/2) - 1][ypos + (height/xFOV/2)] == 16){
      map[xpos + (width/xFOV/2) - 1][ypos + (height/xFOV/2)] = 18;
    }
    if(map[xpos + (width/xFOV/2) - 1][ypos + (height/xFOV/2) - 1] == 16){
      map[xpos + (width/xFOV/2) - 1][ypos + (height/xFOV/2)- 1] = 18;
    }
    if(map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2) - 1] == 16){
      map[xpos + (width/xFOV/2)][ypos + (height/xFOV/2)- 1] = 18;
    }
    if(map[xpos + (width/xFOV/2) - 1][ypos + (height/xFOV/2) + 1] == 16){
      map[xpos + (width/xFOV/2) - 1][ypos + (height/xFOV/2)+ 1] = 18;
    }
    if(map[xpos + (width/xFOV/2) + 1][ypos + (height/xFOV/2) - 1] == 16){
      map[xpos + (width/xFOV/2) + 1][ypos + (height/xFOV/2)- 1] = 18;
    }
  }
  drawTerrain();
  if((playerColor == 1 || playerColor == 4) && (tileValue <= 6 || (tileValue >= 16 && tileValue < 18)) || (playerColor == 2 || playerColor == 5) && (tileValue <= 6 || tileValue == 17) || playerColor == 3 && (tileValue < 2 || (tileValue >= 16 && tileValue < 18))){
    xpos = lastxpos;
    ypos = lastypos;
    drawTerrain();
    if((playerColor == 1 || playerColor == 4) && (tileValue <= 6 || (tileValue >= 16 && tileValue < 18)) || (playerColor == 2 || playerColor == 5) && (tileValue <= 6 || tileValue == 17) || playerColor == 3 && (tileValue < 2 || (tileValue >= 16 && tileValue < 18))){
      scene = 0;
    }
  }
  if(objectValue == 1){
    inventory[21]++;
    objectxpos[currentObjectID] = 0;
    objectypos[currentObjectID] = 0;
    objectvalue[currentObjectID] = 0;
  } else if(objectValue == 3){
    inventory[22]++;
    objectxpos[currentObjectID] = 0;
    objectypos[currentObjectID] = 0;
    objectvalue[currentObjectID] = 0;
  } else if(objectValue == 4){
    inventory[20]++;
    objectxpos[currentObjectID] = 0;
    objectypos[currentObjectID] = 0;
    objectvalue[currentObjectID] = 0;
  } else if(objectValue == 2){
    inventory[23]++;
    objectxpos[currentObjectID] = 0;
    objectypos[currentObjectID] = 0;
    objectvalue[currentObjectID] = 0;
  } else if(objectValue == 5){
    inventory[24]++;
    objectxpos[currentObjectID] = 0;
    objectypos[currentObjectID] = 0;
    objectvalue[currentObjectID] = 0;
  }
  objectValue = 0;
}
/*
Mountains:
1: Volcano (250,10,10)
2-4: Mountain Peak (60) (70) (80)
5-6: Mountain (95) (110)
7: Foothills (155)

Plains:
8: Grasslands (0,255,0)
9: Dark Grasslands (0,245,0)

Desert:
10: Desert (255,255,80)
11: Desert Transition (240,240,100)
11: Beach (240,240,100)

Tundra:
12: Tundra (255)
13: Tundra Transition (225,235,245)

Forest:
14: Forest (0,180,0)
15: Forest Transition (0,220,0)

Ocean:
16: Ocean (0,0,255)
17: Deep Ocean (0,0,240)
*/

final int mapSize = 4000;
int[][] map = new int[mapSize + 1][mapSize + 1];

public void drawTerrain(){
  int value = 0;
  for(int i = 0; i < (width / xFOV); i++){for(int j = 0; j < (height / xFOV); j++){
    if(xpos+i > mapSize || xpos+i < 1 || ypos+j > mapSize || ypos+j < 1 || ypos+j > 990){
      fill(0,0,240);
      value = 17;
    }else{
      value = map[xpos+i][ypos+j];
    }
    if(value == 1){fill(250,10,10);}
    else if(value == -1){fill(145,99,7);stroke(0);}
    else if(value == -2){fill(160);stroke(0);}
    else if(value == 2){fill(60);}
    else if(value == 3){fill(70);}
    else if(value == 4){fill(80);}
    else if(value == 5){fill(95);}
    else if(value == 6){fill(110);}
    else if(value == 7){fill(155);}
    else if(value == 8){fill(0,255,0);}
    else if(value == 9){fill(0,245,0);}
    else if(value == 10){fill(255,255,80);}
    else if(value == 11){fill(240,240,100);}
    else if(value == 12){fill(255);}
    else if(value == 13){fill(225,235,245);}
    else if(value == 14){fill(0,180 - 20 * (i % 2) - 20 * (j % 2),0);}
    else if(value == 15){fill(0,220 - 20 * (j % 2) - 20 * (i % 2),0);}
    else if(value == 16){fill(0,0,255);}
    else if(value == 17){fill(0,0,240);}
    else if(value == 18){fill(0,255,255);}
    rectMode(CORNER);
    if(selDir == 1){
      if(i == (width/xFOV/2) - 1 && j == (height/xFOV/2)){
        tileSelectedValue = value;
        selX = xpos + i;
        selY = ypos + j;
        if(framecounter < 2){
          if(selection == 1){
            fill(145,99,7);
            stroke(0);
          } else if(selection == 2){
            fill(160);
            stroke(0);
          }
        }
      }
    } else if(selDir == 2){
      if(i == (width/xFOV/2) && j == (height/xFOV/2) + 1){
        tileSelectedValue = value;
        selX = xpos + i;
        selY = ypos + j;
        if(framecounter < 2){
          if(selection == 1){
            fill(145,99,7);
            stroke(0);
          } else if(selection == 2){
            fill(160);
            stroke(0);
          }
        }
      }
    } else if(selDir == 3){
      if(i == (width/xFOV/2) + 1 && j == (height/xFOV/2)){
        tileSelectedValue = value;
        selX = xpos + i;
        selY = ypos + j;
        if(framecounter < 2){
          if(selection == 1){
            fill(145,99,7);
            stroke(0);
          } else if(selection == 2){
            fill(160);
            stroke(0);
          }
        }
      }
    } else if(selDir == 4){
      if(i == (width/xFOV/2) && j == (height/xFOV/2) - 1){
        tileSelectedValue = value;
        selX = xpos + i;
        selY = ypos + j;
        if(framecounter < 2){
          if(selection == 1){
            fill(145,99,7);
            stroke(0);
          } else if(selection == 2){
            fill(160);
            stroke(0);
          }
        }
      }
    }
    if(i == (width/xFOV/2) && j == (height/xFOV/2)){
      tileValue = value;
      if(playerColor == 1){  
        fill(255,0,0);
        rect(i * xFOV,j * xFOV,xFOV,xFOV);
        textSize(10);
        fill(100,50,50);
        text("N",i * xFOV + xFOV * .1f,j * xFOV + xFOV * .85f);
        textSize(36);
        cSpeed = 1;
      } else if(playerColor == 2){  
        fill(50,50,255);
        rect(i * xFOV,j * xFOV,xFOV,xFOV);
        textSize(10);
        fill(50,50,80);
        text("W",i * xFOV,j * xFOV + xFOV * .85f);
        textSize(36);
        cSpeed = 1;
      } else if(playerColor == 3){  
        fill(50,89,50);
        rect(i * xFOV,j * xFOV,xFOV,xFOV);
        textSize(10);
        fill(170,180,50);
        text("M",i * xFOV,j * xFOV + xFOV * .85f);
        textSize(36);
        cSpeed = 1;
      } else if(playerColor == 4){  
        fill(100,255,100);
        rect(i * xFOV,j * xFOV,xFOV,xFOV);
        textSize(10);
        fill(170,200,170);
        text(" S",i * xFOV,j * xFOV + xFOV * .85f);
        textSize(36);
        cSpeed = 2;
      } else if(playerColor == 5){  
        fill(0,255,255);
        rect(i * xFOV,j * xFOV,xFOV,xFOV);
        textSize(10);
        fill(200,255,255);
        text(" I",i * xFOV,j * xFOV + xFOV * .85f);
        textSize(36);
        cSpeed = 1;
      }
      if(countdown > 0 && countdown % 5 == 1 && ((countdown < 100 && (playerColor == 2 || playerColor == 3)) || (countdown < 55 && (playerColor == 4 || playerColor == 5)))){
        fill(255,0,0);
        rect(i * xFOV,j * xFOV,xFOV,xFOV);
      }
    }else{
      rect(i * xFOV,j * xFOV,xFOV,xFOV);
      noStroke();
    }}
    noStroke();
}}
int[] inventory = new int[30];

public void inventory(){
  fill(155);
  textSize(36);
  text("Items",20,50);
  text("Current Form:",500,50);
  textSize(14);
  text("Wood:",20,120);
  text("Stone:",20,140);
  text("" + inventory[1],70,120);
  text("" + inventory[2],70,140);
  textSize(14);
  if(playerColor == 1){
    text("Normal",500,110);
    text("Passive Ability: None",500,130);
    text("Active Ability (E): Get wood in a forest.",500,145);
  }else if(playerColor == 2){
    text("Swimmer",500,110);
    text("Passive Ability: Navigate shallow water.",500,130);
  }else if(playerColor == 3){
    text("Climber",500,110);
    text("Passive Ability: Navigate mountains.",500,130);
    text("Active Ability (E): Get stone from a mountain.",500,145);
  }else if(playerColor == 4){
    text("Sprinter",500,110);
    text("Passive Ability: Double your speed.",500,130);
    text("Active Ability (E): Get wood in a forest.",500,145);
  }else if(playerColor == 5){
    text("Iceman",500,110);
    text("Passive Ability: Freeze water into ice.",500,130);
  }
  textSize(16);
  ellipseMode(CORNER);
  text("Normal Form: " + inventory [20],10,600);
  fill(200,215,255);
  ellipse(10,610,50,50);
  fill(155);
  text("Press [1]",10,675);
  text("Water Form: " + inventory [21],140,600);
  fill(50,50,200);
  ellipse(140,610,50,50);
  fill(155);
  text("Press [2]",140,675);
  text("Climber Form: " + inventory [22],270,600);
  fill(50,100,50);
  ellipse(270,610,50,50);
  fill(155);
  text("Press [3]",270,675);
  text("Sprinter Form: " + inventory [23],400,600);
  fill(150,255,150);
  ellipse(400,610,50,50);
  fill(155);
  text("Press [4]",400,675);
  text("Iceman Form: " + inventory [24],530,600);
  fill(0,255,255);
  ellipse(530,610,50,50);
  fill(155);
  text("Press [5]",530,675);
}
public void initialize(){
  xpos = mapSize / 2;
  ypos = mapSize / 2;
  selection = 0;
  playerColor = 1;
  for(int i = 0; i < 30; i++){
    inventory[i] = 0;
  }
  countdown = 0;
}

public void framecounter(){
  if(framecounter < 5){
    framecounter++;
  }else if(framecounter == 5){
    framecounter = 0;
    frameruleCounter++;
  }
}
final int objCap = 1000;
int[] objectxpos = new int[objCap];
int[] objectypos = new int[objCap];
int[] objectvalue = new int[objCap];

public void drawObjects(){
  for(int o = 0; o < objCap; o++){
    for(int i = 0; i < (width / xFOV); i++){for(int j = 0; j < (height / xFOV); j++){
      if(objectxpos[o] == xpos+i && objectypos[o] == ypos+j){
        ellipseMode(CORNER);
        if(objectvalue[o] == 1){
          fill(50,50,200);
        } else if(objectvalue[o] == 2){
          fill(150,255,150);
        } else if(objectvalue[o] == 3){
          fill(50,100,50);
        } else if(objectvalue[o] == 4){
          fill(200,215,255);
        } else if(objectvalue[o] == 5){
          fill(0,255,255);
        } else {
          noFill();
        }
        if(i == (width/xFOV/2) && j == (height/xFOV/2) && objectvalue[o] > 0){
          objectValue = objectvalue[o];
          currentObjectID = o;
        } else {  
          ellipse(i * xFOV,j * xFOV,xFOV,xFOV);
        }
      }
    }}
  }
}

public void createObjects(){
  for(int o = 0; o < objCap; o++){
    objectxpos[o] = PApplet.parseInt(random(4000));
    objectypos[o] = PApplet.parseInt(random(990));
    if(o % 4 == 0){
      objectvalue[o] = 1;
    } else if(o % 5 == 1){
      objectvalue[o] = 2;
    } else if(o % 5 == 2){
      objectvalue[o] = 3;
    } else if(o % 5 == 3){
      objectvalue[o] = 4;
    } else if(o % 5 == 4){
      objectvalue[o] = 5;
    }
  }
}

public void countdown(){
  if(countdown >= 0){
    countdown--;
  }
  if(countdown == 0){
    playerColor = 1;
  }
}
public void takeScreenshot(){
  PImage img = createImage(width, height, RGB);
  img.loadPixels();
  for(int i = 0; i < (width / xFOV); i++){for(int j = 0; j < (height / xFOV); j++){
    for(int vx = 0; vx < xFOV; vx++){for(int yx = 0; yx < xFOV; yx++){
      //img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0, 90, 102); 
      if(map[xpos + i][ypos + j] == 1){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(250,10,10);}
      else if(map[xpos + i][ypos + j] == 2){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(60);}
      else if(map[xpos + i][ypos + j] == 3){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(70);}
      else if(map[xpos + i][ypos + j] == 4){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(80);}
      else if(map[xpos + i][ypos + j] == 5){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(95);}
      else if(map[xpos + i][ypos + j] == 6){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(110);}
      else if(map[xpos + i][ypos + j] == 7){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(155);}
      else if(map[xpos + i][ypos + j] == 8){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0,255,0);}
      else if(map[xpos + i][ypos + j] == 9){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0,245,0);}
      else if(map[xpos + i][ypos + j] == 10){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(255,255,80);}
      else if(map[xpos + i][ypos + j] == 11){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(240,240,100);}
      else if(map[xpos + i][ypos + j] == 12){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(255);}
      else if(map[xpos + i][ypos + j] == 13){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(225,235,245);}
      else if(map[xpos + i][ypos + j] == 14){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0,180 - 20 * (i % 2) - 20 * (j % 2),0);}
      else if(map[xpos + i][ypos + j] == 15){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0,220 - 20 * (j % 2) - 20 * (i % 2),0);}
      else if(map[xpos + i][ypos + j] == 16){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0,0,255);}
      else if(map[xpos + i][ypos + j] == 17){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0,0,240);}
      else if(map[xpos + i][ypos + j] == 18){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0,255,255);}
      if(vx == 0 || vx == xFOV || yx == 0 || yx == xFOV){
        if(map[xpos + i][ypos + j] == -1){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0);}
        if(map[xpos + i][ypos + j] == -2){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(0);}
      }else{
        if(map[xpos + i][ypos + j] == -1){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(145,99,7);}
        if(map[xpos + i][ypos + j] == -2){img.pixels[((j*xFOV+yx)*width) + i * xFOV + vx] = color(160);} 
      }
    }}
  }}
  img.updatePixels();
  img.save("screenshots/screenshot-" + (frameruleCounter * 5 + framecounter * (preset + 4) * 17) + ".png");
}
/*
            Terrain Generator
    Created by Yoctobyte and MrJoCrafter

                  Presets
0: Normal
1: Southwestern Europe
2: Hyrule
3: Middle East
4: Indonesia
5: Desert Archipelago
6: Winter Wonderland
7: China
8: Random
*/

final int xFOV = 10;
int preset = 0;
float s = 1;
float l = 0.5f;
float bc = 0.04f;
float speed = 4000000;
float x = 0;
float y = -s;
float t0 = 1;
float t1 = 1;
float r0 = 1;
float c0 = 0.01f;
float c1 = 0.01f;
float br0 = 1;
float bt0 = 2;
float bt1 = 2;
float bc0 = 0.01f;
float bc1 = 0.01f;
float bl = 0.6f;
float bb = 0.01f;
float wr0 = 1;
float wt0 = 5;
float wt1 = 5;
float wc0 = 0.01f;
float wc1 = 0.01f;
float wl = 0.50f;
float wb = 0.05f;
float tr0 = 1;
float tt0 = 10;
float tt1 = 10;
float tc0 = 0.01f;
float tc1 = 0.01f;
float tl = 0.5f;
float fc = 1;
float rbnd = 0;

//Set the window size and certain other parameters

public void terrainGenSetup() {
  x = 0;
  y = -s;
  noStroke(); 
  if (preset == 1){l = 0.299f;tl = 0.6f;} 
  else if (preset == 2){l =  0.189f;tl = 0.6f;} 
  else if (preset == 3){l = 0.45f;tl = 0.9f;wl = 0.2f;bc = 0.1f;bl = 0.8f;} 
  else if (preset == 4){l = 0.6f;tl = 0.8f;wl = 0.7f;bl = 0.3f;} 
  else if (preset == 5){l = 0.8f;tl = 0.9f;wl = 0.2f;bl = 0.9f;bc = 0.1f;} 
  else if (preset == 6){wl = 0.2f;tl = 0.1f;l = .4f;bl = 0.7f;} 
  else if (preset == 7){l = .4f;wl = 0.8f;tl = 0.5f;bl = 0.55f;} 
  else if (preset == 8){l = random(1);wl = random(1);tl = random(1);bl = random(1);bc = random(.5f);} 
  else if (preset == 9){wl = 0.2f;tl = 0.001f;l = .6f;bl = 0.9f;bc = 0.01f;} 
  else if (preset == 11){c0 = .1f;}
}

//Generate the terrain
public void terrainGenDraw() { 
  int z = 0; for(int i = 0; i < speed; i ++) {
  r0 = noise(t0,t1); 
  br0 = noise(bt0,bt1);
  wr0 = noise(wt0,wt1); 
  tr0 = noise(tt0,tt1);
  if(r0 > l*2.1f && wr0 > wl && br0 > bl){
    // Volcano
    z = 1;
  }else if(r0 > l*2){
    // Mountain
    z = 2;
  }else if(r0 > l*1.9f){
    // Mountain
    z = 3;
  }else if(r0 > l*1.8f){
    // Mountain
    z = 4;
  }else if(r0 > l*1.7f){
    // Mountain
    z = 5;
  }else if(r0 > l*1.6f){
    // Mountain
    z = 6;
  }else if(r0 > l*1.5f){
    // Mountain
    z = 7;
  }else if(r0 > l ){ 
    // Plains Biome
    z = 8;
    if(tr0 < tl-.1f){
      if(wr0 > wl){ 
      // Desert Biome
      z = 10; 
      } 
      if(wr0 > wl-wb && wr0 < wl){ 
      // Desert Transition Biome
      z = 11; 
      } 
    }else if(tr0 > tl+.1f){
      if(wr0 > wl){ 
      // Winter Biome
      z = 12; 
      } else if(wr0 > wl-wb && wr0 < wl){ 
      // Winter Transition Biome
      z = 13; 
      }
    }else{
      // Darkgrass Biome
      z = 9;
    }
    if(br0 > bl){ 
    // Forest Biome
    z = 14;
    } 
    if(br0 > bl-bb && br0 < bl){ 
    // Forest Transition
    z = 15;
    } 
  }else if(r0 > (l-bc) && r0 < l){ 
    // Beach
    z = 11; 
  }else if(r0 < l*0.5f){
    // Deep Ocean
    z = 17;
  }else{
    if(tr0 > tl+.2f){
      //Frozen Ocean
      z = 18;
    }else{
      // Ocean
      z = 16;
    }
  }
  map[PApplet.parseInt(x)][PApplet.parseInt(y) + 1] = z; 
  x += s;
  if(x > mapSize) { x = 0; y += s; t0 = 1;  t1 += c1; bt1 += bc1; bt0 = 1; wt1 += wc1; wt0 = 1; tt1 += tc1; tt0 = 1;}
  t0 += c0; bt0 += bc0; wt0 += wc0; tt0 += tc0;}}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "secretlands" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
